import React, { Component } from 'react';
import { Link, Route, Switch } from 'react-router-dom';



class Home extends Component {

      render() {
           
            
            
            return (
                  <div className="home">
                  <img className="hands" src="/images/hands.jpg" />

            </div>
            )
      }
}
export default Home