const initialState = {
  students: [], teachers:[]
}

const rootReducer = (state = initialState, action) => {
  console.log(state)
  console.log(action)
  switch(action.type){
    case "ADD_STUDENT":
      return {...state, students: [...state.students, action.payload]}
      case "REMOVE_STUDENT":
      return{...state,students:[...state.students, action.payload]}
      case "ADD_FEEDING":
      return{...state, students:[...state.students.feeding, action.payload]}
      case "ADD_MEDS":
      return{...state, students:[...state.students.meds, action.payload]}
      case "ADD_NAP":
      return{...state, students:[...state.students.nap, action.payload]}
      case "ADD_COMMENTS":
      return{...state, students:[...state.students.comments, action.payload]}
      case "ADD_SUPPLIES":
      return{...state, students:[...state.students.supplies, action.payload]}
      case "ADD_DIAPERING":
      return{...state, students:[...state.students.diapering, action.payload]}
      case "ADD_PLAYTIME":
      return{...state, students:[...state.students.playtime, action.payload]}
      case "CHANGE_STATUS":
      return{...state, students:[...state.students.status, action.payload]}
      case "ADD_TEACHER":
      return{...state, teachers:[...state.teachers, action.payload]}
      case "REMOVE_TEACHER":
      return{...state, teachers:[...state.teachers, action.payload]}
      case "ADD_CLASSROOM":
      return{...state, classrooms:[...state.classrooms, action.payload]}
      case "REMOVE_CLASSROOM":
      return{...state, classrooms:[...state.classrooms, action.payload]}
    default:
      return state;
  }
}

export default rootReducer;