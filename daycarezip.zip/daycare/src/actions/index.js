const addStudent = student => ({
  type: "ADD_STUDENT", payload: student
})
const addDiapering = student => ({
  type: "ADD_DIAPERING", payload: student
})
const addFeeding = student => ({
  type: "ADD_FEEDING", payload: student
})
const addNap = student => ({
  type: "ADD_NAP", payload: student
})
const addMeds = student => ({
  type: "ADD_MEDS", payload: student
})
const addComments = student => ({
  type: "ADD_COMMENTS", payload: student
})
const addSupplies = student => ({
  type: "ADD_SUPPLIES", payload: student
})
const removeStudent = student => ({
  type: "REMOVE_STUDENT", payload: student
})
const addPlayTime = student => ({
  type: "ADD_PLAYTIME", payload: student
})
const changeStatus = student => ({
  type: "CHANGE_STATUS", payload: student
})
const addTeacher = teacher =>({
  type: "ADD_TEACHER", payload: teacher
})
const removeTeacher = teacher =>({
  type:"REMOVE_TEACHER", payload:teacher
})
const addClassroom = classroom =>({
  type: "ADD_CLASSROOM", payload:classroom
})
const removeClassroom = classroom =>({
  type: "REMOVE_CLASSROOM", payload: classroom
})
export {addStudent, addDiapering, addFeeding, addNap, addMeds, addComments, addSupplies, removeStudent, addPlayTime, studentStatus}