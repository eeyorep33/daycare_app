const report=[{ id: 1,name:'Evelyn', student_id: 2,room:9,teacher_id: 1,feeding:[],nap:[],comments:[], meds:[], diapering:[],playtime:[],supplies:[],status:'out', email:''}]
const student={id: 1, name:'', room:"", status: "", email:""}
const teacher= {id: 2, name:'', initials:'',room:"", status:''}