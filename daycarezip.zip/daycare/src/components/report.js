import React, { Component } from 'react';

class DailyReport extends Component {
      render() {
            return (
                  <div>
                        <p>Date</p>
                        <p>Name:</p>
                        <p>Room:</p>
                        <p>Teachers:</p>
                        <p>Check-in Time:</p>
                        <p>Check-out Time:</p>
                        <p>Playtime:</p>
                        <p>Feeding:</p>
                        <p>Diapering:</p>
                        <p>Naps:</p>
                        <p>Supplies:</p>
                        <p>Medications:</p>
                        <p>Comments:</p>
                  </div>
            )
      }
}
export default DailyReport