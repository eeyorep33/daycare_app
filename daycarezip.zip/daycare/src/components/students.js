import React, { Component } from 'react';
import TimePicker from 'rc-time-picker'
import moment from 'moment';
import ReactDOM from 'react-dom';
import {addStudent, addDiapering, addFeeding, addNap, addMeds, addComments, addSupplies, removeStudent, addPlayTime, studentStatus} from '../actions/index'

class Student extends Component {
      render() {
            const { match, location } = this.props
            const format = 'h:mm a';
            const now = moment().hour(6).minute(30);
            return (<div>
                  <p>student name</p>
                  <p>Status</p>
                  <p>Check-in</p>
                  <form>
                        <label>Last Diaper Change</label>
                        <TimePicker
                              showSecond={false}
                              defaultValue={now}
                              className="xxx"
                              format={format}
                              use12Hours
                              inputReadOnly
                        />
                        <label>Last Feeding</label>
                        <TimePicker
                              showSecond={false}
                              defaultValue={now}
                              className="xxx"
                              format={format}
                              use12Hours
                              inputReadOnly
                        />
                        <label>Last Medication</label>
                        <TimePicker
                              showSecond={false}
                              defaultValue={now}
                              className="xxx"
                              format={format}
                              use12Hours
                              inputReadOnly
                        />
                        <button type="submit" name="submit">Check-in</button>
                  </form>
                  <form>
                        <div>
                              <label className='add'>Add diaper change:</label>
                              <TimePicker
                                    showSecond={false}
                                    defaultValue={now}
                                    className="xxx"
                                    format={format}
                                    use12Hours
                                    inputReadOnly
                              />
                              <label>B/W</label>
                              <select>
                                    <option value='B'>B</option>
                                    <option value='W'>W</option>
                              </select>
                              <select>
                                    <option value='AL'>AL</option>
                                    <option value='KH'>KH</option>
                                    <option value='BF'>BF</option>
                              </select>
                              <button type='submit'>Add</button>
                        </div>
                        <div>
                              <label className='add'>Add feeding:</label>
                              <TimePicker
                                    showSecond={false}
                                    defaultValue={now}
                                    className="xxx"
                                    format={format}
                                    use12Hours
                                    inputReadOnly
                              />
                              <label>Food type</label>
                              <input type='text' name='food'/>
                              <label>Amount</label>
                              <input type='text' name='amount'/>
                              <button type='submit'>Add</button>
                        </div>
                        <div>
                              <label className='add'>Add play time: </label>
                             <label>Type</label>
                             <input type='text' name='playType'/>
                             <label>Activity</label>
                             <input type='text' name='activity'/>
                              <button type='submit'>Add</button>
                        </div>
                        <div>
                              <label className='add'>Add nap:</label>
                              <label>Start time</label>
                              <TimePicker
                                    showSecond={false}
                                    defaultValue={now}
                                    className="xxx"
                                    format={format}
                                    use12Hours
                                    inputReadOnly
                              />
                               <label>Stop time</label>
                              <TimePicker
                                    showSecond={false}
                                    defaultValue={now}
                                    className="xxx"
                                    format={format}
                                    use12Hours
                                    inputReadOnly
                              />
                              <button type='submit'>Add</button>
                        </div>
                        <div>
                              <label className='add'>Add meds:</label>
                              <TimePicker
                                    showSecond={false}
                                    defaultValue={now}
                                    className="xxx"
                                    format={format}
                                    use12Hours
                                    inputReadOnly
                              />
                              <label>Name</label>
                              <input type='text' name='medName'/>
                              <label>Dosage</label>
                              <input type='text' name='dosage'/>
                              <button type='submit'>Add</button>
                        </div>
                        <div>
                              <label className='add'>Add supplies:</label>
                              <input type="text" name='supplies'/>
                              <button type='submit'>Add</button>
                        </div>
                        <div>
                              <label className='add'>Add comments:</label>
                             <input type="text" name='comments'/>
                              <button type='submit'>Add</button>
                        </div>

                  </form>
            </div>
            )
      }
}
export default Student