import React, {Component} from 'react';
import {Switch, Route, Link} from 'react-router-dom'
import Student from './students'


class Classroom extends Component {
      render(){
            const { match, location } = this.props
           
            return(
                  <div>

                       <p>List of students in room that are links to student page</p>
                       <p>Add Student</p>
                       <form>
                             <label>Name</label>
                             <input type="text" name="name"/>
                             <label>Room</label>
                             <input type="text" name="room"/>
                             <label>Email</label>
                             <input type='email' name='email'/>
                             
                             </form>
                             <button><Link to='/student/1'>student</Link></button>
                           <Switch>
                                   <Route path="/student/:id" render={(props)=>(
                                   <Student {...props}/>)} />
                            </Switch>
                        </div>
            )
      }
}
export default Classroom
