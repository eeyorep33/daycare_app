const knexConfig = require('../knexfile')
const knex = require('knex')(knexConfig)
const bookshelf = require('bookshelf')(knex)
module.exports = (app) => {
      const students = require('./controllers/studentController')

      app.get('/students', (req, res) => {
            students.getStudents().then((students) => { res.send(students) })
      })
     
} 
