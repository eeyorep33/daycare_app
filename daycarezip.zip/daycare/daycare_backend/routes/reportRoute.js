const knexConfig = require('../knexfile')
const knex = require('knex')(knexConfig)
const bookshelf = require('bookshelf')(knex)
module.exports = (app) => {
      const report = require('./controllers/reportController')

      app.post('/report', (req, res) => {
           report.createReport(req.body).then((report) => {
                  server.send({
                        text: req.body.name +
                          "Date: " +req.body.date +
                          "Meals: " + 
                         req.body.feedings.map((item)=>{

                         }) + 
                         "Diapering: " +
                         req.body.diapering.map((item)=>{

                         }) + 
                         "Naps: " +
                         req.body.naps.map((item)=>{

                         }) + 
                         "Play Time: " +
                         req.body.playTime.map((item)=>{

                         }) + "Meds" +
                         req.body.meds.map((item)=>{

                         }) + 
                         "Supplies: " +
                         req.body.supplies + 
                         "Comments: " +
                         req.body.comments,
                       
                        from: "eeyorep33@gmail.com",
                        to: req.body.email,
                        subject: 'Daily Report for' + req.body.name 
                  }, function (err, message) {
                        console.log(err || message);
                        res.send('card sent!')
                  });
            })
      })
      app.get('/report/:id', (req, res) => {
            report.getReport({ id: req.params.id }).then((report) => {
                  res.send(report)
            })
      })

} 