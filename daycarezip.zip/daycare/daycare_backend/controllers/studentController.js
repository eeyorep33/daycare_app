const knexConfig = require('../knexfile')
const knex = require('knex')(knexConfig)
const bookshelf = require('bookshelf')(knex)
const Student = bookshelf.Model.extend({
      tableName: 'students',
})

exports.getStudents = () => {
      return Students.fetchAll()
            .then(result => {
                  const students = result.models.map(student => {
                        return student.attributes
                  })
                  return students
            })
            .catch(err => {
                  console.log(err)
            })
}