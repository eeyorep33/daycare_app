
exports.seed = function (knex, Promise) {
  // Deletes ALL existing entries
  return knex('reports').del()
    .then(function () {
      // Inserts seed entries
      return knex('reports').insert([
        {
          id: 1, name: 'Evelyn',
          date: '2/6/18',
          room: 2,
          teacher_id: 1,
          feedings: [
            { time: '10:00 am', food: 'bottle', amount: '8 oz' },
            { time: '12:00 pm', food: 'cheerios', amount: 'most' },
            { time: '2:00 pm', food: 'bottle', amount: '7 oz' }],
          diapering: [
            { time: '6:45 am', type: 'W', initials: 'AL' },
            { time: '8:45 am', type: 'B', initials: 'AL' },
            { time: '10:45', type: 'W', initials: 'AS' }],
          naps: [
            { startTime: '8:00 am', stopTime: '8:30 am', duration: ':30' },
            { startTime: '1:00 pm', stopTime: '2:10 pm', duration: '1:10' }],
          playTime: [
            { type: 'motor skills', activity: 'putting blocks in holes' }],
          meds: [
            { time: '8:00 am', name: 'inhaler', amount: '2 puffs' },
            { time: '12:00 pm', name: 'inhaler', amount: '2 puffs' }],
          supplies: ["need snacks"],
          comments: [],
          email: 'kenpendlebury@gmail.com'
        },
        {
          id: 2,
          name: 'Amanda',
          date: '3/5/18',
          room: 3,
          teacher_id: 2,
          feedings: [
            { time: '8:00 am', food: 'bottle', amount: '6 oz' },
            { time: '10:00 am', food: 'baby food', amount: 'all' },
            { time: '12:00 pm', food: 'bottle', amount: '3 oz' }],
          diapering: [
            { time: '7:30 am', type: 'W', initials: 'GF' },
            { time: '9:30 am', type: 'W', initials: 'GF' },
            { time: '10:30 am', type: 'B', initials: 'AL' }],
          naps: [
            { startTime: '1:12 pm', stopTime: '2:09 pm', duration: ':57' }],
          playTime: [
            { type: 'Cognitive Development', activity: 'The crunchy bunch' },
            { type: 'social emotional', activity: 'big rule, little rule' }],
          meds: [
            { time: '', name: '', amount: '' }],
          supplies: [],
          comments: ["Was fussy all day"],
          email: 'susanpendlebury@gmail.com'
        },
        {
          id: 3,
          name: 'Matthew',
          date: '6/30/18',
          room: 1,
          teacher_id: 3,
          feedings: [
            { time: '7:00 am', food: 'bottle', amount: '5 oz' },
            { time: '9:00 am', food: 'gold fish', amount: 'some' },
            { time: '11:00 am', food: 'baby food', amount: 'none' }],
          diapering: [
            { time: '6:45 am', type: 'W', initials: 'NB' },
            { time: '7:15 am', type: 'B', initials: 'NB' },
            { time: '9:15 am', type: 'W', initials: 'KL' }],
          naps: [
            { startTime: '7:23 am', stopTime: '9:45 am', duration: '2:22' }],
          playTime: [
            { type: 'Language arts', activity: 'Our names, our things' }],
          meds: [
            { time: '10:00 am', name: 'Amoxicillan', amount: '5 ml' }],
          supplies: ["need diapers", 'need wipes'],
          comments: [],
          email: 'eeyorep33@gmail.com'
        }
      ]);
    });
};
