
exports.seed = function(knex, Promise) {
  // Deletes ALL existing entries
  return knex('teachers').del()
    .then(function () {
      // Inserts seed entries
      return knex('teachers').insert([
        {id: 1, name: 'Alisha', room:1, initials:'AS', status:'out'},
        {id: 2, name: 'Alexis', room:2, initials:'AL', status:'out'},
        {id: 3, name: 'Kim', room:3, initials:'KH', status:'out'}
      ]);
    });
};
