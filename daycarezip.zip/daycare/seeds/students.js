
exports.seed = function(knex, Promise) {
  // Deletes ALL existing entries
  return knex('students').del()
    .then(function () {
      // Inserts seed entries
      return knex('students').insert([
        {id: 1, name:'Evelyn', room:1, status:'out', email:'kenpendlebury@gmail.com'},
        {id: 2, name:'Amanda', room:2, status:'out', email:'susanpendlebury@gmail.com'},
        {id: 3, name:'Matthew', room:3, status:'out', email:'eeyorep33@gmail.com'}
      ]);
    });
};
