
exports.up = function (knex, Promise) {
      return knex.schema.createTableIfNotExists('reports', function (table) {
          table.increments('id').primary();
          table.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
          table.timestamp('updated_at').notNullable().defaultTo(knex.fn.now());
          table.string('name').notNullable();
          table.string('date').notNullable();
          table.integer('room').notNullable();
          table.string('feedings');
          table.string('diapering');
          table.string('naps');
          table.string('meds');
          table.string('playTime');
          table.string('supplies');
          table.string('comments');
          table.string('email').notNullable()
          table.integer('teacher_id').notNullable()
               })
  };
  
  exports.down = function (knex, Promise) {
      return knex.schema.dropTable('reports') // drop table when reverting
  };